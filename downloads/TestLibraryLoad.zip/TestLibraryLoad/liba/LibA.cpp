﻿#define LIBAPI_IMPL
#include "liba/LibA.h"
#include "libc/LibC.h"
#include <iostream>

LIBAPI void SayA()
{
	std::cout << "I'm liba." << std::endl;

	SayC();
}
