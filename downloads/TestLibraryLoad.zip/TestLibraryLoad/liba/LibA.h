﻿#ifndef LibA_h__
#define LibA_h__

#include "lib.h"

LIBAPI void SayA();

#endif // LibA_h__
