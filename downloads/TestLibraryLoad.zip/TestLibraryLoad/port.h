﻿#ifndef port_h_
#define port_h_

#include <string>

typedef void* HLIB;
inline HLIB LoadNativeLibrary(const char* file);
inline bool FreeNativeLibrary(HLIB lib);
inline void* GetSymbolFromNativeLibrary(HLIB lib, const char* name);

inline std::string GetRunPath();

#ifdef WIN32
#include "port_win.h"
#else
#include "port_posix.h"
#endif

#endif
