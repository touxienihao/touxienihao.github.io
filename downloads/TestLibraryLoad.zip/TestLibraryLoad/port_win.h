﻿#ifndef port_win_h_
#define port_win_h_

#include <Windows.h>
#include <Shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

HLIB LoadNativeLibrary( const char* file )
{
	return ::LoadLibraryA(file);
}

bool FreeNativeLibrary( HLIB lib )
{
	return ::FreeLibrary((HMODULE)lib) == TRUE;
}

void* GetSymbolFromNativeLibrary( HLIB lib, const char* name )
{
	return ::GetProcAddress((HMODULE)lib, name);
}

std::string GetRunPath()
{
	char szExePath[MAX_PATH];
	::GetModuleFileNameA(NULL, szExePath, MAX_PATH);
	::PathRemoveFileSpecA(szExePath);
	::PathAddBackslashA(szExePath);
	return szExePath;
}

#endif
