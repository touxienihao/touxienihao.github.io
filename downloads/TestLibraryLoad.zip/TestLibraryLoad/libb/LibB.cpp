﻿#define LIBAPI_IMPL
#include "libb/LibB.h"
#include "libc/LibC.h"
#include <iostream>

LIBAPI void SayB()
{
	std::cout << "I'm libb." << std::endl;

	SayC();
}
