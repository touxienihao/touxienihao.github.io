﻿#ifndef LibB_h__
#define LibB_h__

#include "lib.h"

LIBAPI void SayB();

#endif // LibB_h__
