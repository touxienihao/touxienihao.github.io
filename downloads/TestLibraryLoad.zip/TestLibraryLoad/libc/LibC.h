﻿#ifndef LibC_h__
#define LibC_h__

#include "lib.h"

LIBAPI void SayC();

#endif // LibC_h__
