﻿#define LIBAPI_IMPL
#include "libc/LibC.h"
#include <iostream>

LIBAPI void SayC()
{
	std::cout << "I'm libc." << std::endl;
}
