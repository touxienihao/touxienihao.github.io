﻿#include <iostream>
#include <cassert>
#include <cstdlib>
#include <cstring>

#include "port.h"

typedef void (*FUNC_SAY)();

int main()
{
	// 加载 libmgr

#ifdef WIN32
#define LibMgr "libmgr.dll"
#else
#define LibMgr "libmgr.so"
#endif

   std::string strLibMgr = GetRunPath() + LibMgr;
    HLIB hLibMgr = LoadNativeLibrary(strLibMgr.c_str());
    if (hLibMgr == NULL)
    {
	    std::cout << "libexe : Failed to load libmgr" << std::endl;
        return 0;
    }
	FUNC_SAY pSay = (FUNC_SAY)GetSymbolFromNativeLibrary(hLibMgr, "SayMgr");
	if (pSay == NULL)
	{
	    std::cout << "libexe : Failed to find say function in libmgr" << std::endl;
	    FreeNativeLibrary(hLibMgr);
        return 0;
	}
	pSay();
	FreeNativeLibrary(hLibMgr);

#ifdef WIN32
	system("pause");
#endif

	return 0;
}
