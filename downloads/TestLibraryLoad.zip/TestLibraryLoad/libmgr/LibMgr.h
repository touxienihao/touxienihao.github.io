﻿#ifndef LibMgr_h__
#define LibMgr_h__

#include "lib.h"

LIBAPI void SayMgr();

#endif // LibMgr_h__
