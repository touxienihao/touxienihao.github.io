﻿#define LIBAPI_IMPL
#include "libmgr/LibMgr.h"
#include "port.h"
#include <iostream>
#include <cassert>
#include <cstdlib>
#include <cstring>

typedef void (*FUNC_SAY)();

LIBAPI void SayMgr()
{
	std::cout << "I'm libmgr." << std::endl;

#ifdef WIN32
	// 添加环境变量
	DWORD dwSize = ::GetEnvironmentVariableA("PATH", NULL, 0);
	assert(dwSize);
	LPSTR lpEnvPath = new CHAR[dwSize];
	dwSize = ::GetEnvironmentVariableA("PATH", lpEnvPath, dwSize);
	assert(dwSize);
	std::string strCommPath = GetRunPath();
	strCommPath += "comm";
	std::string strEnvPath = lpEnvPath;
	strEnvPath += ";" + strCommPath;
	BOOL bSet = ::SetEnvironmentVariableA("PATH", strEnvPath.c_str());
	assert(bSet);
#else
    /*
     * The loader reads the value of getenv("LD_LIBRARY_PATH") once,and
     * save it away,long before the first instruction of your executable
     * runs. Subsequent modification of LD_LIBRARY_PATH by the program 
     * only affects any children it execve() s, but not the process itself.
     *
     * The usual way around this is to either re- execute the process(Java does this),
     * or to use a shell wrapper which sets the environment and then exec's the real binary(Firefox does that).
     */
    /*
    std::string strLDEnv;
    char* pLDEnv = getenv("LD_LIBRARY_PATH");
    if (pLDEnv)
    {
        strLDEnv = pLDEnv;
        strLDEnv += ":";
    }
    strLDEnv += GetRunPath();
    strLDEnv += "comm";
    strLDEnv = "LD_LIBRARY_PATH=" + strLDEnv;
    char* pData = (char*)malloc(strLDEnv.size() + 1);
    strcpy(pData, strLDEnv.c_str()); 
    pData[strLDEnv.size()] = 0;
    putenv(pData);
    std::cout << pData << std::endl;
    */
#endif

#ifdef WIN32
#define PATHSPE "\\"
#define LIBA "liba.dll"
#define LIBB "libb.dll"
#else
#define PATHSPE "/"
#define LIBA "liba.so"
#define LIBB "libb.so"
#endif

    std::string strExePath = GetRunPath();
    
    std::string strLibsPath = strExePath;
    strLibsPath += "libs";
    strLibsPath += PATHSPE;
    
    HLIB hLibA = LoadNativeLibrary((strLibsPath + LIBA).c_str());
	if (hLibA)
	{
		FUNC_SAY pSay = (FUNC_SAY)GetSymbolFromNativeLibrary(hLibA, "SayA");
		if (pSay)
			pSay();
        FreeNativeLibrary(hLibA);
	}

	HLIB hLibB = LoadNativeLibrary((strLibsPath + LIBB).c_str());
	if (hLibB)
	{
		FUNC_SAY pSay = (FUNC_SAY)GetSymbolFromNativeLibrary(hLibB, "SayB");
		if (pSay)
			pSay();
        FreeNativeLibrary(hLibB);
	}
}
