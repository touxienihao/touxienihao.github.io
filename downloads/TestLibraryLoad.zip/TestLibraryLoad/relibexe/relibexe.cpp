#include <iostream>
#include <string>
#include <unistd.h>
#include <cstdlib>
#include <cstring>

std::string GetRunPath()
{
    char szPath[256];
    readlink("/proc/self/exe", szPath, 256);
    std::string strPath = szPath;
    std::size_t index = strPath.rfind('/');
    if (index == std::string::npos)
       return "";
   return strPath.substr(0, index + 1);
}

int main()
{
    /*
     * The loader reads the value of getenv("LD_LIBRARY_PATH") once,and
     * save it away,long before the first instruction of your executable
     * runs. Subsequent modification of LD_LIBRARY_PATH by the program 
     * only affects any children it execve() s, but not the process itself.
     *
     * The usual way around this is to either re- execute the process(Java does this),
     * or to use a shell wrapper which sets the environment and then exec's the real binary(Firefox does that).
     */
    std::string strLDEnv;
    char* pLDEnv = getenv("LD_LIBRARY_PATH");
    if (pLDEnv)
    {
        strLDEnv = pLDEnv;
        strLDEnv += ":";
    }
    strLDEnv += GetRunPath();
    strLDEnv += "comm";
    strLDEnv = "LD_LIBRARY_PATH=" + strLDEnv;
    char* pData = (char*)malloc(strLDEnv.size() + 1);
    strcpy(pData, strLDEnv.c_str()); 
    pData[strLDEnv.size()] = 0;
    putenv(pData);
    // std::cout << pData << std::endl;

    std::string strLibExe = GetRunPath() + "libexe";
    pid_t pid = fork();
    if (pid == 0)
        execl(strLibExe.c_str(), (char*)0);
    return 0;
}
