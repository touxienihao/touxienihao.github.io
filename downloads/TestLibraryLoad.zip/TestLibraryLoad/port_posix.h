﻿#ifndef port_posix_h_
#define port_posix_h_

#include <unistd.h>
#include <dlfcn.h>
#include <iostream>

HLIB LoadNativeLibrary(const char* file)
{
    HLIB hLib = dlopen(file, RTLD_LAZY);
    if (hLib == 0)
        std::cout << dlerror() << std::endl;
    return hLib;
}

bool FreeNativeLibrary(HLIB lib)
{
    return dlclose(lib);
}

void* GetSymbolFromNativeLibrary(HLIB lib, const char* name)
{
    return dlsym(lib, name);
}

std::string GetRunPath()
{
    char szPath[256];
    readlink("/proc/self/exe", szPath, 256);
    std::string strPath = szPath;
    std::size_t index = strPath.rfind('/');
    if (index == std::string::npos)
       return "";
   return strPath.substr(0, index + 1);
}

#endif
