﻿#ifndef lib_h__
#define lib_h__

#ifdef WIN32

	// Windows
	#ifdef LIBAPI_IMPL
	#define LIBAPI extern "C" __declspec(dllexport)
	#else
	#define LIBAPI extern "C" __declspec(dllimport)
	#endif

#else
	
	// Linux
    #ifdef LIBAPI_IMPL
	#define LIBAPI extern "C" __attribute__((visibility("default")))
    #else
    #define LIBAPI 
    #endif

#endif

#endif // lib_h__


