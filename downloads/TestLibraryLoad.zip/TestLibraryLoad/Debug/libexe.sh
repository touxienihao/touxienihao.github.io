#!/bin/sh

# libexe launcher

RUNDIR=$(cd `dirname $0`; pwd)
LIBDIR=$RUNDIR/comm

if [ "Z$LD_LIBRARY_PATH" != Z ] ; then
  LD_LIBRARY_PATH=$LIBDIR:$LD_LIBRARY_PATH
else
  LD_LIBRARY_PATH=$LIBDIR
fi

export LD_LIBRARY_PATH

$RUNDIR/libexe

exit 0
